print('2+2=',2+2)
print('50-5*6=',50 - 5*6 )
print('(50-5*6)/4=', (50-5*6)/4)
print('8/5=',8/5)

print('Division details')
print('17 / 3=',17/3)     #always float
print('17 // 3=', 17//3)    #discards fractional part - floor division
print('17 % 3', 17%3)       #modulus
print('5*3+2=',5*3+2)       #checking
print('-----------')
print('5 ** 2=', 5**2)
print('2 ** 7=',2**7)
print('-'*25)
print('mixing int and float')
print('4*3.75-1=',4*3.75-1)   #float as a result
