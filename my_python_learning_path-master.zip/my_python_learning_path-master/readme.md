# This is the place where I will publish my Python learning path
## Examples:
- Code reproduced from learning sources websites
- Exercises I build myself
- Some other related notes