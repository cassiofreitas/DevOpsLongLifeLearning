#this is a block comment
#in Python, there is a PEP 8, a recomendation list of best practices
#It is also important to make good comments.
#variabels i Python have a kind of BP and usually the names are like nome_de_variavel.
greeting = "Hello, World"
teste="#1" # you can use # as string, sure.
print(greeting)	# this is an inline comment
print(teste)

