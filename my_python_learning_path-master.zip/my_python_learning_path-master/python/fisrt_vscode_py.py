name = "cassio"
print(name[1:3])