# freecodecamp_javascript
I am taking some notes, while I´m studying JavaScrip at FreeCodeCamp.
